
interface Pokemon {
  nombre: string;
  altura: number;
  peso: number;
  habilidades: { habilidad: { nombre: string } }[];
  tipos: { tipo: { nombre: string } }[];
}

const getPokemonData = async (pokemonNombre: string): Promise<Pokemon> => {
  const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonNombre}`);
  if (!response.ok) {
    throw new Error(`No se encontró el Pokémon ${pokemonNombre}`);
  }
  return await response.json();
};

const main = async () => {
  try {
    const { nombre, altura, peso, habilidades, tipos } = await getPokemonData('mewtwo');

    console.log(`Nombre: ${nombre}`);
    console.log(`Altura: ${(altura / 10).toFixed(2)} m`);
    console.log(`Peso: ${(peso / 10).toFixed(2)} kg`);
    console.log(`Habilidades: ${habilidades.map(a => a.habilidad.nombre).join(', ')}`);
    console.log(`Tipos: ${tipos.map(t => t.tipo.nombre).join(', ')}`);
  } catch (error) {
    console.error("Error:", error);
  }
};

main();

